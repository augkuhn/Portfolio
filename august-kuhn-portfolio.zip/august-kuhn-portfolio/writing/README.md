# Writing Samples

Three pieces spanning policy analysis, regulatory documentation, and peer-reviewed research.

---

## Regulating Data Centers Through Infrastructure Co-Investment

**Policy memorandum · March 2026 · 13 pages**
📄 [Read the memo](2026-oregon-data-center-policy-memo.pdf)

A memorandum to Oregon's Statewide Data Center Advisory Committee recommending that the state classify data centers as a distinct industrial category and condition their permits on binding co-investment in local water and energy infrastructure.

The argument is structural. Oregon currently splits data center permitting across three unconnected processes: local land use review, water rights allocation through the Oregon Water Resources Department, and utility interconnection through the Public Utility Commission. No single agency sees the cumulative effect. The memo uses Google's twenty-year expansion in The Dalles to show what that fragmentation produces in practice, including a Strategic Investment Program agreement designed for labor-intensive manufacturing being applied to a facility employing roughly 200 people, and a city that had to litigate against its own newspaper before its residents could learn how much municipal water a single industrial user was consuming.

The recommendation adapts Community Benefits Agreements, an established legal instrument in large-scale development, into a mandatory siting condition, and argues that the state already accepted the underlying proportionality principle in its 2025 utility rate reform for large industrial users.

---

## Rogue River-Siskiyou National Forest Travel Management FEIS

**Final Environmental Impact Statement, full format · November 2020 · 14 pages**
📄 [Read the FEIS](2020-rogue-river-siskiyou-travel-management-feis.pdf)

> **Note:** This was prepared as an academic exercise for ES 451, Environmental Policy and Impact Analysis. It is formatted as a genuine USDA Forest Service document but is not an agency publication and carries no official status.

An impact statement analyzing the designation of roads, trails, and areas for wheeled motor vehicle use across the 1.8-million-acre Rogue River-Siskiyou National Forest, implementing Subpart B of the 2005 Travel Management Rule. Five alternatives are evaluated in detail, from No Action through a resource-protective alternative, with a Preferred Alternative identified that blends the Proposed Action with the more restrictive option.

The document follows NEPA structure and CEQ regulations at 40 CFR 1500-1508: cover sheet and abstract, summary, purpose and need, alternatives including those eliminated from detailed study, and affected environment and environmental consequences. Areas of controversy are treated honestly rather than minimized, including serpentine soils, fens and bogs, Port-Orford-cedar root disease and sudden oak death transmission, inventoried roadless areas, and mixed-use road safety.

---

## A Preliminary Study of Soundscape Analysis as a Measurement of Ecosystem Health

**Peer-reviewed article, co-authored · 2015 · 8 pages**
📄 [Read the article](2015-soundscape-analysis-depaul-discoveries.pdf) · 🔗 [Publisher version](https://via.library.depaul.edu/depaul-disc/vol4/iss1/5)

Jachowski, V. M., Kenny, L., Hauer, M., Kühn, A., & Barrett, S. (2015). A Preliminary Study of Soundscape Analysis as a Measurement of Ecosystem Health. *DePaul Discoveries*, 4, Article 5.

An investigation of whether acoustic indices derived from recorded soundscapes can serve as a practical proxy for ecosystem condition. My contribution was to acoustic data collection and processing for the migratory bird component. Open access through Digital Commons@DePaul.

---

Documents are © August Kuhn except where co-authored, and are provided for review. Please ask before reusing or redistributing them.
