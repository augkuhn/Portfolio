# Mammal Community Response to the 2022 McKinney Fire

**A Before-After Control-Impact analysis of Klamath camera-trap data, 2020–2024**

August Kuhn · Institute for Natural Resources · Klamath-Siskiyou Carnivore Project

<p align="center">
  <img src="figures/klamath-mckinney-fire-severity.png" width="450" alt="RAVG burn severity across the McKinney Fire perimeter with camera survey stations">
</p>

---

## The question

The 2022 McKinney Fire burned roughly 60,138 acres of the Klamath National Forest at predominantly moderate-to-high severity. Megafires of this scale are increasingly common in western North America, but mammal community responses are unevenly documented, and most existing studies either lack contemporaneous unburned controls or examine a single taxon in isolation.

**Did the fire produce detectable changes in mammal detection rates and occupancy, and can life-history traits explain the magnitude and direction of the response?**

## Design

| | |
|---|---|
| Camera sites | 76 (44 burned, 32 unburned control) |
| Site-year deployments | 371 |
| Trap-nights | 19,078 |
| Study window | 2020–2024 (2 pre-fire, fire year, 2 post-fire) |
| Functional groups | Rodents, ungulates, mesocarnivores, apex predators, large omnivores |

Site classification was resolved spatially rather than by field notes. Camera coordinates were overlaid on the official McKinney Fire perimeter and the associated soil burn severity raster in ArcGIS Pro. Cameras inside the perimeter were classified as burned; candidate controls were restricted to a 1-mile buffer around the perimeter, so that controls were drawn from the same topographic, climatic, and vegetation context. Detections were collapsed to independent events using a 30-minute independence interval and standardized as detections per 60 trap-nights.

## Analytical approach

Six tests, each answering a different question and each with different weaknesses, so that agreement across them is informative:

| Test | Method | What it isolates |
|---|---|---|
| 1 | Paired Wilcoxon signed-rank, burned sites only | Raw pre-to-post change |
| 2 | Wilcoxon rank-sum, post-fire window only | Burned vs. control contrast after the fire |
| 3 | Negative binomial GLMM, `period + offset(log(trap_nights)) + (1\|site)` | Period effect adjusted for effort and repeated measures |
| 4 | Binomial GLMM on site-year occupancy | Presence/absence shifts that rate models miss |
| 5 | **BACI interaction**, `burned * period` | Fire-attributable change net of background variation |
| 6 | Cliff's delta | Non-parametric effect magnitude |

Test 5 is the primary contrast. A significant `burned × period` interaction means the change at burned sites is not explained by regional variation that also affected controls. Model adequacy was evaluated with DHARMa simulation-based residual diagnostics; all Kolmogorov-Smirnov and dispersion tests were non-significant.

## Results

| Functional group | Direction | BACI p | Interpretation |
|---|---|---|---|
| Rodents | Decrease (-74%) | 0.009 | Canopy-dependent taxa drive the signal |
| Large omnivores | Decrease (-65%) | 0.011 | Likely behavioral avoidance of burned area |
| Ungulates | No change | 0.873 | Slight numerical increase consistent with a forage pulse |
| Mesocarnivores | No change | 0.358 | Occupancy expanded post-fire while abundance stayed flat |
| Apex predators | Insufficient power | n/a | Descriptive comparison only |

The genus-level decomposition is the most informative part of the rodent result. Three canopy- or litter-dependent genera account for the entire aggregate decline (*Tamiasciurus* -86%, *Sciurus* -72%, *Neotamias* -98%), with *Tamiasciurus* showing the strongest BACI interaction in the study (β = -2.39, p < 0.001). Meanwhile *Otospermophilus*, the California ground squirrel, was essentially unchanged in detection rate and was found at twice as many sites post-fire (17 → 34 non-zero site-years).

**The fire restructured the community rather than uniformly suppressing it,** and the mediating variable is dependence on vertical habitat structure. Depressed rates persisted two years post-fire with no evidence of recovery.

## Repository contents

```
mckinney-fire-analysis/
├── mckinney-fire-analysis.Rmd     # Full analysis source
├── mckinney-fire-analysis.html    # Knitted report with code, tables, and figures
├── data/                          # Derived analytical datasets
│   ├── site_year_all_groups.csv        # 1,855 rows: site × year × functional group
│   ├── deployments_clean.csv           # 373 deployment records with effort metadata
│   ├── rodent_genus_descriptive.csv    # Pre/post rates by genus
│   └── rodent_genus_baci_coefficients.csv
├── figures/
└── report/
    └── kuhn-mckinney-fire-baci-report.pdf   # Manuscript-format write-up
```

The knitted HTML is the fastest way to read the analysis: it includes every code chunk, all eleven tables, and the diagnostic plots. GitHub does not render HTML files in the repository browser, so download it and open it locally, or view it through the raw file.

## Reproducing it

```r
install.packages(c("tidyverse", "glmmTMB", "DHARMa", "emmeans",
                   "broom.mixed", "effsize", "knitr", "scales"))

rmarkdown::render("mckinney-fire-analysis.Rmd")
```

Analysis was run under R 4.3.0. All file paths in the `.Rmd` are relative to this directory, so knit with the working directory set here.

## Limitations

1. **Single fire, single landscape.** Generalization to other megafires or forest types should be cautious.
2. **Two-year post-fire window.** This captures the immediate response phase, not medium- or long-term recovery.
3. **Detection rate is not abundance.** Changes in movement or activity patterns can confound population-level interpretation.
4. **Apex predator power.** Detection rates near one per 60 trap-nights preclude inferential modeling for this group.

## Data availability

The CSVs here are derived, site-level aggregates. **Precise camera latitude and longitude have been removed** from `deployments_clean.csv` because the monitoring network includes a state-listed species; the analysis does not use coordinates, so nothing is lost. Raw detection records belong to the Institute for Natural Resources and are housed in Wildlife Insights. Direct data requests there rather than here.
