# GIS Cartography

Maps produced in ArcGIS Pro. Each entry below shows a web-resolution preview; the print-resolution PDF is linked underneath.

---

## Composite Neighborhood Index, Portland Metro Area

<img src="png/portland-composite-neighborhood-index.png" width="500" alt="Composite Neighborhood Index, Portland Metro Area, 2024">

A multi-criteria index ranking Portland-area neighborhoods on four normalized inputs: mean residential sale price, days on market, park acreage, and transit access. The exercise is in weighting and normalization rather than in any single layer, since the four inputs arrive on incompatible scales and units.

**Data:** RMLS 2024 residential property sales; Oregon Metro RLIS (neighborhood organizations, ORCA, TriMet bus stops)
📄 [Full-resolution PDF](pdf/portland-composite-neighborhood-index.pdf)

---

## Black and African American Population by Alabama Congressional District

<img src="png/alabama-congressional-districts-demographics.png" width="500" alt="Black and African American population by Alabama congressional district">

A demographic choropleth of Alabama's congressional districts, classified into seven breaks that range from under 8% to over 54%. The classification is deliberate: the distribution is strongly bimodal, and equal-interval breaks would have collapsed the meaningful variation at both ends.

**Data:** U.S. Census Bureau TIGER/Line shapefiles; ACS 5-Year Estimates 2024, Table DP05
📄 [Full-resolution PDF](pdf/alabama-congressional-districts-demographics.pdf)

---

## Food Cart and Ethnic Market Density, Portland

<img src="png/portland-food-cart-and-market-density.png" width="500" alt="Portland food cart density and ethnic market density by neighborhood">

A paired-panel layout comparing two density surfaces across the same neighborhood geography. Presenting them side by side at matched extents makes the spatial mismatch between the two distributions legible in a way that a single combined surface would obscure.

**Data:** Oregon Metro RLIS 2019, Portland State University
📄 [Full-resolution PDF](pdf/portland-food-cart-and-market-density.pdf)

---

## Mt. Hood Study Area: A Raster Suitability Model

A five-map series building from source terrain data through to a weighted site suitability surface. This is the sequence a real siting analysis follows, and the series is meant to be read in order.

### 1. Distance to nearest highway

<img src="png/mt-hood-01-highway-distance.png" width="380" alt="Euclidean distance to nearest highway, Mt. Hood study area">

Euclidean distance surface, used downstream as an accessibility criterion.
**Data:** USGS 3DEP; U.S. Census Bureau TIGER/Line 2018 · 📄 [PDF](pdf/mt-hood-01-highway-distance.pdf)

### 2. Slope

<img src="png/mt-hood-02-slope.png" width="380" alt="Slope of the Mt. Hood study area">

Slope derived from the 3DEP digital elevation model, classified into eight breaks.
**Data:** USGS 3DEP · 📄 [PDF](pdf/mt-hood-02-slope.pdf)

### 3. National land cover and hillshade

<img src="png/mt-hood-03-land-cover-hillshade.png" width="380" alt="NLCD land cover classes over hillshade, Mt. Hood study area">

NLCD classes rendered over a hillshade, which keeps the terrain readable underneath a full categorical palette.
**Data:** USGS 3DEP; NLCD 2011 · 📄 [PDF](pdf/mt-hood-03-land-cover-hillshade.pdf)

### 4. Building site suitability, unweighted

<img src="png/mt-hood-04-suitability-unweighted.png" width="380" alt="Unweighted building site suitability, Mt. Hood study area">

Reclassified criteria combined with equal influence, producing a baseline surface scored 2.5 to 15.
**Data:** USGS 3DEP · 📄 [PDF](pdf/mt-hood-04-suitability-unweighted.pdf)

### 5. Building site suitability, weighted

<img src="png/mt-hood-05-suitability-weighted.png" width="380" alt="Weighted building site suitability, Mt. Hood study area">

The same criteria under a weighted overlay. Comparing this against map 4 shows how much of the final result is driven by the weighting scheme rather than by the underlying terrain, which is the point of running both.
**Data:** USGS 3DEP · 📄 [PDF](pdf/mt-hood-05-suitability-weighted.pdf)

---

Basemap and reference layers throughout: Esri, TomTom, Garmin, FAO, NOAA, USGS, OpenStreetMap contributors, NASA, NGA, FEMA.

Cartography by August Kuhn. Maps are provided for review; please ask before reusing or redistributing them.
