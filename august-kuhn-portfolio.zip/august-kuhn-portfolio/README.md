# August Kuhn

**Environmental science, wildlife monitoring, and geospatial analysis.**

B.S. Environmental Science and Management, Portland State University (2026) · B.S. Environmental Science and Policy, Southern Oregon University (2020) · ArcGIS Pro Associate Certification (2025) · Portland, Oregon

📧 augkuhn8@gmail.com · 📄 [Resume](cv/kuhn-august-resume-2026.pdf) · 📄 [Full CV](cv/kuhn-august-cv-2026.pdf)

<p align="center">
  <img src="gis/png/portland-composite-neighborhood-index.png" width="520" alt="Composite Neighborhood Index, Portland Metro Area, 2024">
</p>

I work at the intersection of field ecology, statistics, and cartography: camera-trap and vegetation survey data, mixed-effects models in R, and spatial analysis in ArcGIS Pro and QGIS. My current research assistantship with the Institute for Natural Resources on the Klamath-Siskiyou Carnivore Project focuses on how mammal communities respond to megafire.

---

## Contents

| | |
|---|---|
| 🔥 [**McKinney Fire BACI Analysis**](research/mckinney-fire-analysis) | Full R workflow, knitted report, and manuscript on mammal community response to a 60,000-acre megafire |
| 🗺️ [**GIS Cartography**](gis) | Eight maps in ArcGIS Pro: suitability modeling, demographic mapping, density surfaces, composite indices |
| ✍️ [**Writing Samples**](writing) | State policy memo, NEPA impact statement, peer-reviewed publication |
| 📄 [**Resume and CV**](cv) | |

---

## Featured: Mammal Community Response to the 2022 McKinney Fire

A Before-After Control-Impact study of how five mammal functional groups responded to a high-severity megafire in the Klamath National Forest.

<p align="center">
  <img src="research/mckinney-fire-analysis/figures/klamath-mckinney-fire-severity.png" width="420" alt="McKinney Fire burn severity and camera survey station network, Klamath region">
</p>

**Design.** Camera-trap detections from 76 sites (44 inside the fire perimeter, 32 unburned controls within a 1-mile buffer), 371 site-year deployments, and 19,078 trap-nights across two pre-fire years, the fire year, and two post-fire years. Site selection was finalized by overlaying camera coordinates on the official fire perimeter and soil burn severity raster in ArcGIS Pro.

**Methods.** Six complementary tests: paired and unpaired Wilcoxon tests, negative binomial GLMMs with a trap-night offset, binomial occupancy GLMMs, a burned × period BACI interaction as the primary contrast, and Cliff's delta effect sizes. Model adequacy checked with DHARMa simulation-based residual diagnostics.

**Findings.** The fire restructured the community rather than uniformly suppressing it. Rodents declined 74% at burned sites (BACI β = -1.14, p = 0.009) and large omnivores declined 65% (β = -1.43, p = 0.011). Ungulates and mesocarnivores showed no significant fire effect, and mesocarnivore occupancy actually expanded post-fire while per-site rates stayed flat, pointing to redistribution rather than population change. A genus-level decomposition localized the entire rodent signal to canopy-dependent taxa: *Tamiasciurus* carried the strongest interaction in the study (β = -2.39, p < 0.001), while ground-foraging *Otospermophilus* and *Peromyscus* held steady or increased.

📂 [**Read the full analysis →**](research/mckinney-fire-analysis)

---

## GIS Cartography

Eight maps produced in ArcGIS Pro. Full-resolution PDFs and a browsable gallery with data sources are in [`gis/`](gis).

<table>
<tr>
<td width="33%"><img src="gis/png/alabama-congressional-districts-demographics.png" alt="Black and African American population by Alabama congressional district"></td>
<td width="33%"><img src="gis/png/mt-hood-05-suitability-weighted.png" alt="Weighted building site suitability, Mt. Hood study area"></td>
<td width="33%"><img src="gis/png/portland-food-cart-and-market-density.png" alt="Portland food cart and ethnic market density"></td>
</tr>
<tr>
<td align="center"><sub><b>Demographic choropleth</b><br>ACS 5-Year Estimates, TIGER/Line</sub></td>
<td align="center"><sub><b>Raster suitability model</b><br>USGS 3DEP, weighted overlay</sub></td>
<td align="center"><sub><b>Kernel density surfaces</b><br>Oregon Metro RLIS</sub></td>
</tr>
</table>

---

## Writing Samples

**[Regulating Data Centers Through Infrastructure Co-Investment](writing/2026-oregon-data-center-policy-memo.pdf)** (2026)
A policy memorandum to Oregon's Statewide Data Center Advisory Committee arguing that the state should classify data centers as a distinct industrial category and condition permits on binding community benefits agreements. Uses Google's expansion in The Dalles as a case study in regulatory fragmentation across land use, water rights, and utility interconnection.

**[Rogue River-Siskiyou National Forest Travel Management FEIS](writing/2020-rogue-river-siskiyou-travel-management-feis.pdf)** (2020)
A full-format Final Environmental Impact Statement analyzing motor vehicle route designation across 1.8 million acres under the 2005 Travel Management Rule. Five alternatives evaluated in detail, with a preferred alternative identified. *Prepared as an academic exercise for ES 451 Environmental Policy and Impact Analysis. This is not an agency document.*

**[A Preliminary Study of Soundscape Analysis as a Measurement of Ecosystem Health](writing/2015-soundscape-analysis-depaul-discoveries.pdf)** (2015)
Co-authored peer-reviewed article on acoustic indices as a proxy for ecosystem condition. Jachowski, V. M., Kenny, L., Hauer, M., Kühn, A., & Barrett, S. (2015). *DePaul Discoveries*, 4, Article 5. [Publisher version](https://via.library.depaul.edu/depaul-disc/vol4/iss1/5).

---

## Tools

**Analysis** R (tidyverse, glmmTMB, DHARMa, emmeans, ggplot2), R Markdown, mixed-effects and occupancy modeling, non-parametric testing, effect sizes
**Geospatial** ArcGIS Pro, QGIS, raster suitability modeling, kernel density estimation, choropleth design, spatial joins and overlay analysis
**Data** Wildlife Insights, camera-trap detection processing, ecological survey design, data cleaning and QA
**Field and lab** Transect-based vegetation surveys, water/soil/air quality testing, eDNA extraction and PCR

---

## Notes on data and reuse

Analytical CSVs in this repository are derived, site-level summaries. Precise camera coordinates have been removed, since the underlying monitoring network includes a state-listed species. Raw detection records remain the property of the Institute for Natural Resources and the Wildlife Insights platform and are not redistributed here.

Code in this repository is available under the MIT License. Written documents, reports, and maps are © August Kuhn and are provided for review; please ask before reusing or redistributing them.
